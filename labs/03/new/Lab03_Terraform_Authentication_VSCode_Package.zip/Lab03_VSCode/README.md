# QATIPINT AWS Lab 03 for VS Code

Use Windows, VS Code and PowerShell 7.4 or later. AWS CLI v2, Terraform and the existing course repository must already be installed.

Copy all five PS1 files into the existing aws-tf-int/labs/03 directory beside main.tf. Keep Lab03.Common.ps1 beside the other scripts. The original main.tf and any Terraform support files are supplied by the course repository and are not duplicated in this package.

Follow Lab03_Terraform_Authentication_VSCode.docx. The original Bash scripts are not used in this version.

Prerequisites in AWS: an authenticated named lab profile; permission for the administrative IAM and Secrets Manager operations; and the platform-provided policy named terraform-user-policy in the lab account. The same policy is attached to the demonstration IAM user and role. The helper deliberately stops if the policy is missing or the user/secret/role already exists.

The Secrets Manager exercise demonstrates an existing long-lived-key pattern. It still requires an authenticated starting identity. IAM roles and temporary credentials are the preferred direction illustrated in the second exercise.

The setup record lab03-vscode-resources.json contains resource identifiers and an access key ID, not the secret access key. Do not remove it before cleanup. The helpers never display key values or persist a credential environment file. Avoid shell transcription or debug tracing while retrieving credentials.

Cleanup permanently deletes the recorded lab secret without a recovery window, after Terraform-managed resources have been destroyed. It removes the recorded access key, IAM user and IAM role, but not the pre-existing policy. Reusing a just-deleted secret name can require a short wait for AWS deletion to finish.

Validation performed for this package: document rendering and static consistency checks. The PowerShell helpers and AWS provisioning sequence require a trainer run in the target training account; they have not been executed against AWS here.
